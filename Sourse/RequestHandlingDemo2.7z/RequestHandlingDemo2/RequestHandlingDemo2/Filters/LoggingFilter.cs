﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace RequestHandlingDemo2.Filters
{
	public class LoggingFilter : IActionFilter
	{
		public void OnActionExecuting(ActionExecutingContext filterContext)
		{
			var c = filterContext.RouteData.Values["controller"];
		}

		public void OnActionExecuted(ActionExecutedContext filterContext)
		{
			//throw new NotImplementedException();
		}
	}
}