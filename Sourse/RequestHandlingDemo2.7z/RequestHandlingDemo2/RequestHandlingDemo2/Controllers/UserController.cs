﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using RequestHandlingDemo2.Filters;
using RequestHandlingDemo2.Models;

namespace RequestHandlingDemo2.Controllers
{
	//[RoutePrefix("userByAttr")]
    public class UserController : Controller
    {
		[ExceptionFilter]
		[ActionName("GetById")]
		//[Route("{id:long}")]
        public ActionResult GetUser(long id)
        //public ActionResult GetById(long id)
        {
	        if (Request.IsLocal)
	        {
		        //return RedirectToAction("GetById", "User", new {area = "Admin"});
				//return RedirectToRoute("Admin_default", new { area = "Admin" });
	        }
			ViewBag.Greeting = "Hi";
	        var user = UsersRepo.GetById(id);
            return View("User", user);
        }

		[ActionName("GetByName")]
		//[Route("{name}")]
		public ActionResult GetUser(string name)
		//public ActionResult GetByName(string name)
		{
			if (RouteData.Values.ContainsKey("lang"))
			{
				var lang = RouteData.Values["lang"].ToString();
				switch (lang)
				{
					case "ru":
					{
						ViewBag.Greeting = "Привет";
						break;
					}
					default:
					{
						ViewBag.Greeting = "Hi";
						break;
					}
				}
			}

			var user = UsersRepo.GetByName(name);
			return View("User", user);
		}
    }
}