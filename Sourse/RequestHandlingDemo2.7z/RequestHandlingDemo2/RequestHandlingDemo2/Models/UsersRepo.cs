﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RequestHandlingDemo2.Models
{
	public class UsersRepo
	{
		static List<User> _users = new List<User>()
		{
			new User() {Id = 1, Name = "Mike"},
			new User() {Id = 2, Name = "Jhon"}
		};

		public static User GetById(long id)
		{
			return _users.First(x => x.Id == id);
		}

		public static User GetByName(string name)
		{
			return _users.First(x => x.Name == name);
		}
	}

	public class User
	{
		public long Id { get; set; }
		public string Name { get; set; }
	}
}