﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Routing.Constraints;
using System.Web.Routing;
using System.Web.UI.WebControls;

namespace RequestHandlingDemo2
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

			routes.MapMvcAttributeRoutes();

			routes.MapRoute(
				name: "Error",
				url: "error/{error}",
				defaults: new { controller = "Error", action = "Error" }
			);

	        routes.MapRoute(
				name: "UserById",
				url: "user/{id}",
				defaults: new { controller = "User", action = "GetById"},
				//constraints: new { id = new LongRouteConstraint() }
				//constraints: new { id = @"\d+", httpMethod = new HttpMethodConstraint("POST") }
				constraints: new { id = @"\d*" },
				namespaces: new[] { "RequestHandlingDemo2.Controllers" }
	        );

			routes.MapRoute(
				name: "UserByName",
				url: "user/{name}/{lang}",
				defaults: new { controller = "User", action = "GetByName", lang = UrlParameter.Optional },
				//defaults: new { controller = "User", action = "GetByName" },
				namespaces: new[] { "RequestHandlingDemo2.Controllers" }
			);

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional },
				namespaces: new[] { "RequestHandlingDemo2.Controllers" }
            );
        }
    }
}
